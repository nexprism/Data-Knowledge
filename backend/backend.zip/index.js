import dotenv from 'dotenv';
dotenv.config();

import http from 'http';
import { Server } from 'socket.io';
import app from './app.js';
import { connectToDatabase } from './db/connect.js';
import { ServerConfig } from './config/server.config.js';
// import { initRedis } from './config/redisClient.js';
import videoSocketHandler from './sockets/videoSocketHandler.js';
import jwt from 'jsonwebtoken';
import Message from './models/Message.js';
import GroupMessage from './models/GroupMessage.js';
import GroupChatRoom from './models/GroupChatRoom.js';
import CourseChatRoom from './models/CourseChatRoom.js';
import CourseChatMessage from './models/CourseChatMessage.js';
import mongoose from 'mongoose';
import path from 'path';

import './cron/wordPressNewsCron.js';

import express from 'express';

// Serve uploads directory so uploaded files are reachable
app.use('/uploads', express.static(path.join(process.cwd(), 'uploads')));

// Create the HTTP server for Express and Socket.io
const server = http.createServer(app);

const isProduction = process.env.NODE_ENV === 'production';
const socketAllowedOrigins = new Set([
  "http://localhost:5173",
  "http://localhost:5174",
  "http://localhost:5175",
  "http://localhost:3000",
  "http://127.0.0.1:5173",
  "http://127.0.0.1:5174",
  "http://127.0.0.1:5175",
  "http://127.0.0.1:3000",
  "https://dataknowledge.in",
  "https://www.dataknowledge.in",
  "https://api.dataknowledge.in",
  "https://admin.dataknowledge.in",
  "https://classes.dataknowledge.in",
  "https://data-knowledge.onrender.com",
  "https://dataknowledge.vercel.app",
  "https://dataknowledgeadmin.vercel.app",
  "https://edrilla.com",
  "https://www.edrilla.com",
  "https://admin.edrilla.com",
  "https://api.edrilla.com",
  "http://edrila.nexprism.in",
  "https://edrila.nexprism.in",
  "https://lapaas.com",
  "https://www.lapaas.com",
  process.env.ADMIN_URL,
  process.env.CLIENT_URL,
  process.env.FRONTEND_URL,
  ...(process.env.ALLOWED_ORIGINS ? process.env.ALLOWED_ORIGINS.split(',').map(s => s.trim()) : []),
].filter(Boolean));

// Configure Socket.io with CORS
const io = new Server(server, {
  cors: {
    origin: (origin, callback) => {
      if (!origin) return callback(null, true);
      if (!isProduction && /^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(origin)) return callback(null, true);
      if (/^https?:\/\/([a-zA-Z0-9-]+\.)*dataknowledge\.in(:\d+)?$/.test(origin)) return callback(null, true);
      if (/^https?:\/\/([a-zA-Z0-9-]+\.)*vercel\.app$/.test(origin)) return callback(null, true);
      if (/^https?:\/\/([a-zA-Z0-9-]+\.)*onrender\.com$/.test(origin)) return callback(null, true);
      if (socketAllowedOrigins.has(origin)) return callback(null, true);
      callback(new Error('Origin not allowed by CORS'), false);
    },
    methods: ['GET', 'POST'],
    credentials: true
  },
  transports: ['websocket', 'polling']
});

// make io available to controllers via req.app.locals.io
app.locals.io = io;

// Socket.io Authentication Middleware
const onlineUsers = new Map(); // Map userId to socketId

io.use((socket, next) => {
  try {
    const decoded = jwt.verify(
      socket.handshake.auth.token,
      process.env.JWT_ACCESS_TOKEN_SECRET_KEY
    );
    socket.user = decoded;
    socket.emit("authenticated", { userId: decoded._id });
    next();
  } catch (err) {
    socket.emit("auth_error", "Invalid token");
    next(new Error("Authentication error: Invalid token"));
  }
});

// Handle socket connections
io.on('connection', (socket) => {
  //console.log(`✅ Socket connected: ${socket.id}, User: ${socket.user._id}`);

  onlineUsers.set(socket.user?._id?.toString(), socket.id);

  socket.join(socket.user?._id?.toString());

  // Join all group chat rooms the user is part of
  (async () => {
    try {
      const userGroupRooms = await GroupChatRoom.find({ participants: socket.user._id }).select('_id');
      userGroupRooms.forEach((groupRoom) => {
        socket.join(groupRoom._id.toString());
        //console.log(`User ${socket.user._id} joined group room ${groupRoom._id}`);
      });

      // Join all course chat rooms the user is part of
      const userCourseRooms = await CourseChatRoom.find({ participants: socket.user._id }).select('_id');
      userCourseRooms.forEach((courseRoom) => {
        socket.join(`course_${courseRoom._id.toString()}`);
      });
    } catch (err) {
      console.error('Error joining rooms for user:', socket.user._id, err);
    }
  })();

  io.emit('userOnline', { userId: socket.user._id });

  videoSocketHandler(socket);

  // One-on-one message events (unchanged)
  socket.on('sendMessage', async (data) => {
    try {
      const { roomId, receiverId, message: msg, emoji, replyTo } = data;
      // Merge emoji into message for sockets
      const message = emoji ? (msg ? `${msg} ${emoji}` : emoji) : msg;
      if (!roomId || !receiverId || !message) {
        return socket.emit('error', { message: 'Missing required fields: roomId, receiverId, message' });
      }

      // Validate replyTo message exists and belongs to this room if provided
      if (replyTo) {
        const replyToMessage = await Message.findOne({ _id: replyTo, chatRoomId: roomId });
        if (!replyToMessage) {
          return socket.emit('error', { message: 'ReplyTo message not found in this room' });
        }
      }

      const newMessage = await Message.create({
        chatRoomId: roomId,
        sender: socket.user._id,
        receiver: receiverId,
        message,
        replyTo: replyTo || null
      });

      // Update room lastMessage and updatedAt
      await ChatRoom.findByIdAndUpdate(roomId, {
        lastMessage: newMessage._id,
        updatedAt: new Date(),
      });

      // Populate replyTo if it exists
      if (newMessage.replyTo) {
        await newMessage.populate({
          path: 'replyTo',
          select: 'message sender createdAt',
          populate: { path: 'sender', select: 'fullName email' }
        });
      }

      // Populate sender and receiver for response
      await newMessage.populate('sender receiver', 'fullName email profilePicture role');

      // Emit newMessage to receiver
      io.to(receiverId.toString()).emit('newMessage', newMessage);

      socket.emit('messageSent', newMessage);

      // If receiver is admin, broadcast to all admins so Support Team stays in sync
      try {
        const receiverUser = await User.findById(receiverId).select('role').lean();
        if (receiverUser && (receiverUser.role === 'admin' || receiverUser.role === 'super_admin')) {
          const otherAdmins = await User.find({
            role: { $in: ['admin', 'super_admin'] },
            _id: { $nin: [socket.user._id, receiverId] }
          }).select('_id').lean();
          for (const admin of otherAdmins) {
            io.to(admin._id.toString()).emit('newMessage', newMessage);
          }
        }
      } catch (e) {
        console.error('Error forwarding socket message to admins:', e);
      }
    } catch (err) {
      socket.emit('error', { message: err.message });
    }
  });

  socket.on('messageRead', async (data) => {
    try {
      const { roomId, messageId } = data;
      if (!roomId || !messageId) {
        return socket.emit('error', { message: 'Missing required fields: roomId, messageId' });
      }

      const message = await Message.findOneAndUpdate(
        { _id: messageId, chatRoomId: roomId, receiver: socket.user._id },
        { isRead: true },
        { new: true }
      );

      if (!message) {
        return socket.emit('error', { message: 'Message not found or not authorized' });
      }

      const senderSocketId = onlineUsers.get(message.sender.toString());
      if (senderSocketId) {
        io.to(senderSocketId).emit('messageRead', { messageId });
      }
    } catch (err) {
      socket.emit('error', { message: err.message });
    }
  });

  // Group message events (new)
  socket.on('sendGroupMessage', async (data) => {
    try {
      const { groupRoomId, message: msg, emoji } = data;
      const message = emoji ? (msg ? `${msg} ${emoji}` : emoji) : msg;
      if (!groupRoomId || !message) {
        return socket.emit('error', { message: 'Missing required fields: groupRoomId, message' });
      }

      const groupRoom = await GroupChatRoom.findOne({
        _id: groupRoomId,
        participants: socket.user._id
      });

      if (!groupRoom) {
        return socket.emit('error', { message: 'Not authorized to send message in this group chat room' });
      }

      const newGroupMessage = await GroupMessage.create({
        groupChatRoomId: groupRoomId,
        sender: socket.user._id,
        message,
        readBy: [socket.user._id]
      });


      //console.log('sendGroupMessage: New message created', { messageId: newGroupMessage._id, groupRoomId, sender: socket.user._id });

      io.to(groupRoomId.toString()).emit('newGroupMessage', newGroupMessage);
    } catch (err) {
      socket.emit('error', { message: err.message });
    }
  });

  socket.on('markGroupMessagesRead', async (data) => {
    try {
      const { groupRoomId } = data;
      if (!groupRoomId) {
        return socket.emit('error', { message: 'Missing required field: groupRoomId' });
      }

      const groupRoom = await GroupChatRoom.findOne({
        _id: groupRoomId,
        participants: socket.user._id
      });

      if (!groupRoom) {
        return socket.emit('error', { message: 'Not authorized to mark messages in this group chat room' });
      }

      const updateResult = await GroupMessage.updateMany(
        {
          groupChatRoomId: groupRoomId,
          readBy: { $ne: socket.user._id }
        },
        { $addToSet: { readBy: socket.user._id } }
      );

      io.to(groupRoomId.toString()).emit('groupMessagesRead', {
        userId: socket.user._id,
        modifiedCount: updateResult.modifiedCount
      });
    } catch (err) {
      socket.emit('error', { message: err.message });
    }
  });

  // Course chat message events
  socket.on('sendCourseChatMessage', async (data) => {
    try {
      const { courseChatRoomId, message: msg, fileUrl, fileName, fileType, fileSize, emoji, replyTo } = data;
      const message = emoji ? (msg ? `${msg} ${emoji}` : emoji) : msg;

      if (!courseChatRoomId || (!message && !fileUrl)) {
        return socket.emit('error', { message: 'Missing required fields: courseChatRoomId and (message or fileUrl)' });
      }

      // Validate courseChatRoomId
      if (!mongoose.Types.ObjectId.isValid(courseChatRoomId)) {
        return socket.emit('error', { message: 'Invalid course chat room ID' });
      }

      const courseChatRoom = await CourseChatRoom.findOne({
        _id: courseChatRoomId,
        participants: socket.user._id,
        isActive: true
      });

      if (!courseChatRoom) {
        return socket.emit('error', { message: 'Not authorized to send message in this course chat room' });
      }

      // Check for duplicate message within last 5 seconds to prevent spam
      const fiveSecondsAgo = new Date(Date.now() - 5000);
      const duplicateMessage = await CourseChatMessage.findOne({
        courseChatRoomId,
        sender: socket.user._id,
        message: message || null,
        fileUrl: fileUrl || null,
        createdAt: { $gte: fiveSecondsAgo },
        isDeleted: false
      });

      if (duplicateMessage) {
        console.log('Duplicate message detected, skipping:', {
          userId: socket.user._id,
          courseChatRoomId,
          message: message?.substring(0, 50)
        });
        return socket.emit('courseChatMessageSent', {
          messageId: duplicateMessage._id,
          duplicate: true
        });
      }

      // Determine file type automatically if not provided
      let determinedFileType = fileType;
      if (fileUrl && !fileType && fileName) {
        const ext = fileName.toLowerCase().split('.').pop();
        if (['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'].includes(ext)) {
          determinedFileType = 'image';
        } else if (['pdf', 'doc', 'docx', 'txt', 'rtf'].includes(ext)) {
          determinedFileType = 'document';
        } else if (['mp3', 'wav', 'm4a', 'ogg', 'aac', 'webm'].includes(ext)) {
          determinedFileType = 'voice';
        } else {
          determinedFileType = 'other';
        }
      }

      // Create message with unique constraint
      const newCourseChatMessage = await CourseChatMessage.create({
        courseChatRoomId,
        sender: socket.user._id,
        message: message || null,
        fileUrl: fileUrl || null,
        fileName: fileName || null,
        fileType: determinedFileType || null,
        fileSize: fileSize || null,
        readBy: [{ user: socket.user._id }],
        replyTo: replyTo || null
      });

      // Populate sender and replyTo info
      const populatedMessage = await CourseChatMessage.findById(newCourseChatMessage._id)
        .populate('sender', 'fullName email')
        .populate({
          path: 'replyTo',
          select: 'message sender createdAt',
          populate: { path: 'sender', select: 'fullName email' }
        })
        .lean();

      console.log('Course message created successfully:', {
        messageId: populatedMessage._id,
        courseChatRoomId,
        sender: populatedMessage.sender.fullName,
        hasFile: !!populatedMessage.fileUrl
      });

      // Send to course room participants only once
      io.to(`course_${courseChatRoomId.toString()}`).emit('newCourseChatMessage', populatedMessage);

      // Send confirmation to sender
      socket.emit('courseChatMessageSent', {
        messageId: newCourseChatMessage._id,
        success: true,
        timestamp: populatedMessage.createdAt
      });

    } catch (err) {
      console.error('Course chat message error:', err);

      // Handle duplicate key error from MongoDB
      if (err.code === 11000) {
        return socket.emit('courseChatMessageSent', {
          duplicate: true,
          message: 'Message already exists'
        });
      }

      socket.emit('error', { message: err.message });
    }
  });

  socket.on('markCourseChatMessagesRead', async (data) => {
    try {
      const { courseChatRoomId } = data;
      if (!courseChatRoomId) {
        return socket.emit('error', { message: 'Missing required field: courseChatRoomId' });
      }

      if (!mongoose.Types.ObjectId.isValid(courseChatRoomId)) {
        return socket.emit('error', { message: 'Invalid course chat room ID' });
      }

      const courseChatRoom = await CourseChatRoom.findOne({
        _id: courseChatRoomId,
        participants: socket.user._id,
        isActive: true
      });

      if (!courseChatRoom) {
        return socket.emit('error', { message: 'Not authorized to mark messages in this course chat room' });
      }

      const updateResult = await CourseChatMessage.updateMany(
        {
          courseChatRoomId: courseChatRoomId,
          'readBy.user': { $ne: socket.user._id }
        },
        { $addToSet: { readBy: { user: socket.user._id } } }
      );

      // Notify course room about read status
      io.to(`course_${courseChatRoomId.toString()}`).emit('courseChatMessagesRead', {
        userId: socket.user._id,
        courseChatRoomId,
        modifiedCount: updateResult.modifiedCount
      });

    } catch (err) {
      console.error('Mark course chat messages read error:', err);
      socket.emit('error', { message: err.message });
    }
  });

  socket.on('disconnect', () => {
    //console.log(`❌ Socket disconnected: ${socket.id}, User: ${socket.user?._id}`);
    onlineUsers.delete(socket.user?._id?.toString());
    io.emit('userOffline', { userId: socket.user?._id });
  });
});

// Start server and initialize DB + Redis
const PORT = process.env.PORT || ServerConfig.port || 4000;

server.listen(PORT, async () => {
  try {
    await connectToDatabase();
    // await initRedis();
    console.log(`🚀 Server + WebSocket running on port ${PORT}`);
  } catch (error) {
    console.error('❌ Error starting server:', error);
    process.exit(1);
  }
});
